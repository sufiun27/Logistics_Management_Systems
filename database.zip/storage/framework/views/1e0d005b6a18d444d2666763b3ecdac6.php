<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('exportFormApparel.exportFormApparel')); ?>" class="btn btn-success btn-sm">Back</a>
    </div>
    <?php if (isset($component)) { $__componentOriginal2342e1caa3b5224183b4572420a79d31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2342e1caa3b5224183b4572420a79d31 = $attributes; } ?>
<?php $component = App\View\Components\Message::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Message::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $attributes = $__attributesOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__attributesOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $component = $__componentOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__componentOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
    <div class="card-body">
        <form action="<?php echo e(route('exportFormApparel.exportFormApparelUpdate', $exportForm->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <?php $__currentLoopData = [
                        ['item_name', 'Item Name', 'text', false],
                        ['hs_code', 'HS Code', 'text', false],
                        ['hs_code_second', 'HS Code Second', 'text', false],
                        ['invoice_no', 'Invoice No', 'text', true],
                        ['invoice_date', 'Invoice Date', 'date', false],
                        ['contract_no', 'Contract No', 'text', false],
                        ['contract_date', 'Contract Date', 'date', false]
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $label, $type, $required]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="<?php echo e($name); ?>" class="col-sm-3 text-end control-label col-form-label"><?php echo e($label); ?>:</label>
                        <div class="col-sm-9">
                            <input type="<?php echo e($type); ?>" <?php echo e($required ? 'required' : ''); ?> name="<?php echo e($name); ?>" class="form-control" id="<?php echo e($name); ?>" placeholder="<?php echo e($label); ?>" value="<?php echo e(old($name, $exportForm->$name)); ?>" />
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="col-6">
                    <div class="form-group row">
                        <label for="consignee_name" class="col-sm-3 text-end control-label col-form-label">Consignee Name:</label>
                        <div class="col-sm-9">
                            <select id="consignee_name" required name="consignee_name" class="form-control">
                                <option value="">Select Consignee Name</option>
                                <?php $__currentLoopData = $consignees->unique('consignee_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consignee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($consignee->consignee_name); ?>" <?php echo e(old('consignee_name', $exportForm->consignee_name) == $consignee->consignee_name ? 'selected' : ''); ?>><?php echo e($consignee->consignee_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php $__currentLoopData = [
                        ['consignee_site', 'Consignee Site'],
                        ['consignee_country', 'Consignee Country'],
                        ['consignee_address', 'Consignee Address']
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="<?php echo e($name); ?>" class="col-sm-3 text-end control-label col-form-label"><?php echo e($label); ?>:</label>
                        <div class="col-sm-9">
                            <select id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="form-control" disabled data-old="<?php echo e(old($name, $exportForm->$name)); ?>">
                                <option value="">Select <?php echo e($label); ?></option>
                            </select>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <hr>

                    <div class="form-group row">
                        <label for="notify_name" class="col-sm-3 text-end control-label col-form-label">Notify:</label>
                        <div class="col-sm-9">
                            <select id="notify_name" required name="notify_name" class="form-control">
                                <option value="">Select Notify</option>
                                <?php $__currentLoopData = $notifies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($notify->name); ?>" <?php echo e(old('notify_name', $exportForm->notify_name) == $notify->name ? 'selected' : ''); ?>><?php echo e($notify->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group row mt-3">
                            <label for="notify_address" class="col-sm-3 text-end control-label col-form-label">Address:</label>
                            <div class="col-sm-9">
                                <input type="text" id="notify_address" name="notify_address" class="form-control"
                                    value="<?php echo e(old('notify_address', $exportForm->notify_address)); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <!-- Destination Country & Transport Information -->
                    <div class="form-group row">
                        <label for="dst_country_name" class="col-sm-3 text-end control-label col-form-label">Destination Country:</label>
                        <div class="col-sm-9">
                            <select id="dst_country_name" required name="dst_country_name" class="form-control">
                                <option value="">Select Destination Country</option>
                                <?php $__currentLoopData = $dest_countries->unique('country_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destcountry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($destcountry->country_name); ?>" <?php echo e(old('dst_country_name', $exportForm->dst_country_name) == $destcountry->country_name ? 'selected' : ''); ?>><?php echo e($destcountry->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php $__currentLoopData = [
                        ['dst_country_code', 'Country Code'],
                        ['dst_country_port', 'Port']
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="<?php echo e($name); ?>" class="col-sm-3 text-end control-label col-form-label"><?php echo e($label); ?>:</label>
                        <div class="col-sm-9">
                            <select id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="form-control" disabled data-old="<?php echo e(old($name, $exportForm->$name)); ?>">
                                <option value="">Select <?php echo e($label); ?></option>
                            </select>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <hr>
                    <!-- Transport Information Entry -->
                    <div class="form-group row">
                        <label for="transport_name" class="col-sm-3 text-end control-label col-form-label">Transport Name:</label>
                        <div class="col-sm-9">
                            <select id="transport_name" required name="transport_name" class="form-control">
                                <option value="">Select Transport Name</option>
                                <?php $__currentLoopData = $transports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($transport->name); ?>" <?php echo e(old('transport_name', $exportForm->transport_name) == $transport->name ? 'selected' : ''); ?>><?php echo e($transport->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php $__currentLoopData = [
                        ['transport_address', 'Transport Address'],
                        ['transport_port', 'Transport Port']
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="<?php echo e($name); ?>" class="col-sm-3 text-end control-label col-form-label"><?php echo e($label); ?>:</label>
                        <div class="col-sm-9">
                            <select id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="form-control" disabled data-old="<?php echo e(old($name, $exportForm->$name)); ?>">
                                <option value="">Select <?php echo e($label); ?></option>
                            </select>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="section" class="col-sm-3 text-end control-label col-form-label">Section:</label>
                        <div class="col-sm-9">
                            <input readonly name="section" id="section" type="text" class="form-control" value="Private" placeholder="Private"/>
                        </div>
                    </div>

                    <hr>

                    <div class="form-group row">
                        <label for="tt_no" class="col-sm-3 text-end control-label col-form-label">TT No:</label>
                        <div class="col-sm-9">
                            <input name="tt_no" required id="tt_no" type="text" class="form-control" value="<?php echo e(old('tt_no', $exportForm->tt_no)); ?>" placeholder="Put TT No"/>
                            <span id="tt_validation" class="text-danger"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="invoice_site" class="col-sm-3 text-end control-label col-form-label">Create By Site:</label>
                        <div class="col-sm-9">
                            <input type="text" name="invoice_site" id="invoice_site" class="form-control" value="<?php echo e(old('invoice_site', $exportForm->invoice_site)); ?>" placeholder="Put Origin Site">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tt_date" class="col-sm-3 text-end control-label col-form-label">TT Date:</label>
                        <div class="col-sm-9">
                            <input name="tt_date" required id="tt_date" type="date" class="form-control" value="<?php echo e(old('tt_date', $exportForm->tt_date)); ?>" placeholder="Put TT date"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- Quantity & Value Entry -->
                <div class="col-6">
                    <h4>Quantity & Value Entry</h4>
                    <hr>
                    <div class="form-group row">
                        <label for="unit" class="col-sm-3 text-end control-label col-form-label">Unit:</label>
                        <div class="col-sm-9">
                            <select id="unit" required name="unit" class="form-control">
                                <option value="PCS" <?php echo e(old('unit', $exportForm->unit) == 'PCS' ? 'selected' : ''); ?>>PCS</option>
                                <option value="SET" <?php echo e(old('unit', $exportForm->unit) == 'SET' ? 'selected' : ''); ?>>SET</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="quantity" class="col-sm-3 text-end control-label col-form-label">Quantity:</label>
                        <div class="col-sm-9">
                            <input required name="quantity" id="quantity" type="number" class="form-control" value="<?php echo e(old('quantity', $exportForm->quantity)); ?>" placeholder="Quantity"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="currency" class="col-sm-3 text-end control-label col-form-label">Currency:</label>
                        <div class="col-sm-9">
                            <select required id="currency" name="currency" class="form-control">
                                <option value="USDollers" <?php echo e(old('currency', $exportForm->currency) == 'USDollers' ? 'selected' : ''); ?>>USDollers</option>
                                <option value="EUros" <?php echo e(old('currency', $exportForm->currency) == 'EUros' ? 'selected' : ''); ?>>EUros</option>
                                <option value="Pound" <?php echo e(old('currency', $exportForm->currency) == 'Pound' ? 'selected' : ''); ?>>Pound</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="amount" class="col-sm-3 text-end control-label col-form-label">Amount:</label>
                        <div class="col-sm-9">
                            <input required name="amount" id="amount" type="number" class="form-control" value="<?php echo e(old('amount', $exportForm->amount)); ?>" placeholder="Amount"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cm_percentage" class="col-sm-3 text-end control-label col-form-label">CM Percentage:</label>
                        <div class="col-sm-9">
                            <input required readonly name="cm_percentage" id="cm_percentage" type="number" class="form-control" value="<?php echo e($cmValue->cm_value); ?>" placeholder="..%"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="incoterm" class="col-sm-3 text-end control-label col-form-label">Incoterm:</label>
                        <div class="col-sm-9">
                            <select id="incoterm" required name="incoterm" class="form-control">
                                <option value="">Select Incoterm</option>
                                <?php $__currentLoopData = ['FOB','CPT','CFR','DDP','FCA','CIF','DAP','EXW','CnF']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incoterm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($incoterm); ?>" <?php echo e(old('incoterm', $exportForm->incoterm) == $incoterm ? 'selected' : ''); ?>><?php echo e($incoterm); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="cm_amount" class="col-sm-3 text-end control-label col-form-label">CM Amount:</label>
                        <div class="col-sm-9">
                            <div id="incoterm_calculation">Calculate Automatically</div>
                        </div>
                    </div>
                    <div id="freight_value"></div>
                </div>

                <div class="col-6">
                    <h4>Ex-Factory Information Entry</h4>
                    <hr>
                    <?php $__currentLoopData = [
                        ['exp_no', 'Exp No', 'number'],
                        ['exp_date', 'Exp Date', 'date'],
                        ['exp_permit_no', 'Exp Permit No', 'text'],
                        ['bl_no', 'B/L No', 'text'],
                        ['bl_date', 'B/L Date', 'date'],
                        ['ex_factory_date', 'EX-Factory Date', 'date']
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $label, $type]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group row">
                        <label for="<?php echo e($name); ?>" class="col-sm-3 text-end control-label col-form-label"><?php echo e($label); ?>:</label>
                        <div class="col-sm-9">
                            <input name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" type="<?php echo e($type); ?>" class="form-control" value="<?php echo e(old($name, $exportForm->$name)); ?>" placeholder="<?php echo e($label); ?>"/>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
var consignees = <?php echo json_encode($consignees, 15, 512) ?>;
var dest_countries = <?php echo json_encode($dest_countries, 15, 512) ?>;
var transports = <?php echo json_encode($transports, 15, 512) ?>;
var notifies = <?php echo json_encode($notifies, 15, 512) ?>;

$(document).ready(function() {
    // Notify Cascade
    $('#notify_name').on('change', function() {
        var selectedName = $(this).val();
        if (selectedName) {
            var notify = notifies.find(n => n.name === selectedName);
            $('#notify_address').val(notify ? notify.address : '');
        } else {
            $('#notify_address').val('');
        }
    });

    // Consignee Cascade with auto-select
    $('#consignee_name').on('change', function() {
        var consigneeName = $(this).val();
        $('#consignee_site').prop('disabled', true).html('<option value="">Select Consignee Site</option>');
        $('#consignee_country').prop('disabled', true).html('<option value="">Select Consignee Country</option>');
        $('#consignee_address').prop('disabled', true).html('<option value="">Select Consignee Address</option>');
        if (consigneeName) {
            var sites = [...new Set(consignees.filter(c => c.consignee_name === consigneeName).map(c => c.consignee_site))];
            $('#consignee_site').html('<option value="">Select Consignee Site</option>' + sites.map(site => `<option value="${site}">${site}</option>`).join(''));
            $('#consignee_site').prop('disabled', false);

            // Auto-select old value if present
            var oldSite = $('#consignee_site').data('old');
            if (oldSite) {
                $('#consignee_site').val(oldSite).trigger('change');
            }
        }
    });
    $('#consignee_site').on('change', function() {
        var consigneeName = $('#consignee_name').val();
        var consigneeSite = $(this).val();
        $('#consignee_country').prop('disabled', true).html('<option value="">Select Consignee Country</option>');
        $('#consignee_address').prop('disabled', true).html('<option value="">Select Consignee Address</option>');
        if (consigneeSite) {
            var countries = [...new Set(consignees.filter(c => c.consignee_name === consigneeName && c.consignee_site === consigneeSite).map(c => c.consignee_country))];
            $('#consignee_country').html('<option value="">Select Consignee Country</option>' + countries.map(country => `<option value="${country}">${country}</option>`).join(''));
            $('#consignee_country').prop('disabled', false);

            var oldCountry = $('#consignee_country').data('old');
            if (oldCountry) {
                $('#consignee_country').val(oldCountry).trigger('change');
            }
        }
    });
    $('#consignee_country').on('change', function() {
        var consigneeName = $('#consignee_name').val();
        var consigneeSite = $('#consignee_site').val();
        var consigneeCountry = $(this).val();
        $('#consignee_address').prop('disabled', true).html('<option value="">Select Consignee Address</option>');
        if (consigneeCountry) {
            var addresses = [...new Set(consignees.filter(c => c.consignee_name === consigneeName && c.consignee_site === consigneeSite && c.consignee_country === consigneeCountry).map(c => c.consignee_address))];
            $('#consignee_address').html('<option value="">Select Consignee Address</option>' + addresses.map(address => `<option value="${address}">${address}</option>`).join(''));
            $('#consignee_address').prop('disabled', false);

            var oldAddress = $('#consignee_address').data('old');
            if (oldAddress) {
                $('#consignee_address').val(oldAddress);
            }
        }
    });

    // Destination Country Cascade with auto-select
    $('#dst_country_name').on('change', function() {
        var countryName = $(this).val();
        $('#dst_country_code').prop('disabled', true).html('<option value="">Select Country Code</option>');
        $('#dst_country_port').prop('disabled', true).html('<option value="">Select Port</option>');
        if (countryName) {
            var codes = [...new Set(dest_countries.filter(c => c.country_name === countryName).map(c => c.country_code))];
            $('#dst_country_code').html('<option value="">Select Country Code</option>' + codes.map(code => `<option value="${code}">${code}</option>`).join(''));
            $('#dst_country_code').prop('disabled', false);

            var oldCode = $('#dst_country_code').data('old');
            if (oldCode) {
                $('#dst_country_code').val(oldCode).trigger('change');
            }
        }
    });
    $('#dst_country_code').on('change', function() {
        var countryName = $('#dst_country_name').val();
        var countryCode = $(this).val();
        $('#dst_country_port').prop('disabled', true).html('<option value="">Select Port</option>');
        if (countryCode) {
            var ports = [...new Set(dest_countries.filter(c => c.country_name === countryName && c.country_code === countryCode).map(c => c.port))];
            $('#dst_country_port').html('<option value="">Select Port</option>' + ports.map(port => `<option value="${port}">${port}</option>`).join(''));
            $('#dst_country_port').prop('disabled', false);

            var oldPort = $('#dst_country_port').data('old');
            if (oldPort) {
                $('#dst_country_port').val(oldPort);
            }
        }
    });

    // Transport Cascade with auto-select
    $('#transport_name').on('change', function() {
        var transportName = $(this).val();
        $('#transport_address').prop('disabled', true).html('<option value="">Select Transport Address</option>');
        $('#transport_port').prop('disabled', true).html('<option value="">Select Transport Port</option>');
        if (transportName) {
            var addresses = [...new Set(transports.filter(t => t.name === transportName).map(t => t.address))];
            $('#transport_address').html('<option value="">Select Transport Address</option>' + addresses.map(address => `<option value="${address}">${address}</option>`).join(''));
            $('#transport_address').prop('disabled', false);

            var oldAddress = $('#transport_address').data('old');
            if (oldAddress) {
                $('#transport_address').val(oldAddress).trigger('change');
            }
        }
    });
    $('#transport_address').on('change', function() {
        var transportName = $('#transport_name').val();
        var transportAddress = $(this).val();
        $('#transport_port').prop('disabled', true).html('<option value="">Select Transport Port</option>');
        if (transportAddress) {
            var ports = [...new Set(transports.filter(t => t.name === transportName && t.address === transportAddress).map(t => t.port))];
            $('#transport_port').html('<option value="">Select Transport Port</option>' + ports.map(port => `<option value="${port}">${port}</option>`).join(''));
            $('#transport_port').prop('disabled', false);

            var oldPort = $('#transport_port').data('old');
            if (oldPort) {
                $('#transport_port').val(oldPort);
            }
        }
    });

    // TT No Validation (AJAX)
    $('#tt_no').on('input', function() {
        var tt_no = $(this).val();
        if(tt_no.length > 0){
            $.ajax({
                url: "<?php echo e(route('exportFormApparel.addExportFormApparelTtNo')); ?>",
                type: "POST",
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "tt_no": tt_no
                },
                success: function(response) {
                    $('#tt_validation').html(response);
                }
            });
        } else {
            $('#tt_validation').html('');
        }
    });

    // Incoterm Calculation
    function updateIncotermCalculation() {
        var cm_percentage = parseFloat($('#cm_percentage').val());
        var amount = parseFloat($('#amount').val());
        var incoterm = $('#incoterm').val();

        if (!isNaN(cm_percentage) && !isNaN(amount) && incoterm) {
            if (['FOB', 'CFR', 'FCA', 'EXW', 'CnF'].includes(incoterm)) {
                var incoterm_calculation = (amount / 100) * cm_percentage;
                var output = '<input readonly name="cm_amount" id="cm_amount" type="text" class="form-control" value="' + incoterm_calculation.toFixed(2) + '" placeholder="' + incoterm_calculation.toFixed(2) + '"/>';
                $('#incoterm_calculation').html(output);
                $('#freight_value').html('');
            } else if (['CPT', 'CIF', 'DAP', 'DDP'].includes(incoterm)) {
                var incoterm_calculation = (amount / 100) * cm_percentage;
                var output = '<input readonly name="cm_amount" id="cm_amount" type="text" class="form-control" value="' + incoterm_calculation.toFixed(2) + '" placeholder="' + incoterm_calculation.toFixed(2) + '"/>';
                var output1 = '<div class="form-group row">' +
                             '<label for="freight_value_input" class="col-sm-3 text-end control-label col-form-label">Freight Value:</label>' +
                             '<div class="col-sm-9">' +
                             '<input name="freight_value" id="freight_value_input" type="text" class="form-control" placeholder="Freight Value"/>' +
                             '</div></div>';
                $('#incoterm_calculation').html(output);
                $('#freight_value').html(output1);
            } else {
                $('#incoterm_calculation').html('Calculate Automatically');
                $('#freight_value').html('');
            }
        } else {
            $('#incoterm_calculation').html('Calculate Automatically');
            $('#freight_value').html('');
        }
    }

    $('#cm_percentage, #amount').on('input', updateIncotermCalculation);
    $('#incoterm').on('change', updateIncotermCalculation);

    // On page load, trigger only the first dropdown in each cascade
    if($('#consignee_name').val()){
        $('#consignee_name').trigger('change');
    }
    if($('#dst_country_name').val()){
        $('#dst_country_name').trigger('change');
    }
    if($('#transport_name').val()){
        $('#transport_name').trigger('change');
    }
    if($('#notify_name').val()){
        $('#notify_name').trigger('change');
    }
    updateIncotermCalculation();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/exportFormApparel/exportFormApparelEdit.blade.php ENDPATH**/ ?>