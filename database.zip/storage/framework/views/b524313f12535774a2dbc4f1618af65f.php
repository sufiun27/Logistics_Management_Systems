<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('export.addExporter')); ?>" class="btn btn-success btn-sm">Add New</a>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="card-body">
        
        <table class="table table-striped table-sm">
            <thead class="table-danger">
                
                    
                        <tr>
                            <th><b>Exporter No</b></th>
                            <th><b>Exporter Name</b></th>
                            <th><b>Exporter Address</b></th>
                            <th><b>Registration Details</b></th>
                            <th><b>EPB.REG</b></th>
                            <th colspan="2""><b>Action</b></th>
                            </tr>
                    </thead>
                
            </thead>
            <tbody>
                <?php $__currentLoopData = $exporters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exporters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td><?php echo e($exporters->ExpoterNo); ?></td>
                    <td><?php echo e($exporters->ExpoterName); ?></td>
                    <td><?php echo e($exporters->ExpoterAddress); ?></td>
                    <td><?php echo e($exporters->RegDetails); ?></td>
                    <td><?php echo e($exporters->EPBReg); ?></td>
                    <td ><a href="<?php echo e(route('export.editExporter', $exporters->id)); ?>" class="btn btn-info btn-sm">Edit</a></td>
                    <td><a href="<?php echo e(route('export.deleteExporter', $exporters->id)); ?>" class="btn btn-danger btn-sm">Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/export/exporter.blade.php ENDPATH**/ ?>