<?php $__env->startSection('basic_table_css'); ?>
   
    <link
      rel="stylesheet"
      type="text/css"
      href="<?php echo e(asset('matrix/assets/extra-libs/multicheck/multicheck.css')); ?>"
    />
    <link
      href="<?php echo e(asset('matrix/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>"
      rel="stylesheet"
    />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- ==================================================== -->
<!-- Include this in your Blade view where you want to display messages -->
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>


<!-- ============================================================== -->

        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
          <!-- ============================================================== -->
          <!-- Start Page Content -->
          <!-- ============================================================== -->
          <div class="row">
            <div class="col-12">

              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Employee</h5>
                  <div class="table-responsive">
                    <table  class="table table-striped table-bordered table-info">

                      <thead>
                        <tr>
                        <th>ID</th>
                          <th>Name</th>
                          
                          <th>Designation</th>
                          <th>Department</th>
                          <th>site</th>
                          <th>Email</th>
                          <th>Phone</th>
                          <th>Address</th>
                          <th>remarks</th>
                 
                        </tr>
                      </thead>
                      <tbody>
                        
                     
                            <tr>
                                <td><?php echo e($employee->emp_id); ?></td>
                                <td><?php echo e($employee->name); ?></td>                               
                                <td><?php echo e($employee->designation); ?></td>
                                <td><?php echo e($employee->department); ?></td>
                                <td><?php echo e($employee->site); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td><?php echo e($employee->phone); ?></td>
                                <td><?php echo e($employee->address); ?></td>
                                <td><?php echo e($employee->remarks); ?></td>

                            </tr>
                      </tbody>
                      
                    </table>
                  </div>
                </div>
              </div>


            </div>
          </div>    
          <!-- end row -->
          <!-- ////user permission table -->
          <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Granted Permission List</h5>
                  <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm p-0 m-0">
                      <thead class="table-info">
                        <tr>
                        <th>Modeule</th>
                          <th>Name</th>
                          <th>status</th>
                          <th>Action</th>
                        </tr>  
                      </thead>
                      <tbody>
                        
                        <?php $__currentLoopData = $user_permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>                            
                                <td><?php echo e($user_permissions->permission->module); ?></td>   
                                <td><?php echo e($user_permissions->permission->name); ?></td>   
                                <td
                                  <?php if($user_permissions->status == 1): ?>
                                  class="table-success">
                                      Active
                                  <?php else: ?>
                                  class="table-danger">
                                      Deactive
                                  <?php endif; ?>
                                </td>
                                <td>
                                    
                                    <div class="btn-group">
                                    <button type="button" class="btn btn-primary dropdown-toggle btn-xs" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="mdi mdi-table-edit"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li class="text-center"><a class="dropdown-item btn btn-xs bg-success" href="<?php echo e(route('employee.permissions.activate', ['id' => $user_permissions->id])); ?>">Active</a></li>
                                        <li class="text-center"><a class="dropdown-item btn btn-xs bg-warning" href="<?php echo e(route('employee.permissions.deactivate', ['id' => $user_permissions->id])); ?>">Deactive</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li class="text-center"><a class="dropdown-item btn btn-xs bg-danger" href="<?php echo e(route('employee.permissions.remove', ['id' => $user_permissions->id])); ?>">Remove</a></li>
                                    </ul>

                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      
                  </table>
                      
                    

          <!-- ////Give permission table -->
          <div class="row">
            <div class="col-12">

              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Permission List</h5>
                  <div class="table-responsive">
                    <table
                      id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead class="table-primary">
                        <tr>
                        <th>Modeule</th>
                          <th>Name</th>
                          <th>Description</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($permissions->module); ?></td>
                                <td><?php echo e($permissions->name); ?></td>
                                <td><?php echo e($permissions->description); ?></td>
                                  <td><a href="<?php echo e(route('employee.permissions.add', ['e_id' => $employee->id, 'p_id' => $permissions->id])); ?>" class="btn btn-success btn-xs">Add</a></td>
                                  
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <tfoot>
                        <tr>
                        <th>Module</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Action</th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            
            </div>
          </div>




          <!-- ============================================================== -->
          <!-- End PAge Content -->
          <!-- ============================================================== -->
          <!-- ============================================================== -->
          <!-- Right sidebar -->
          <!-- ============================================================== -->
          <!-- .right-sidebar -->
          <!-- ============================================================== -->
          <!-- End Right sidebar -->
          <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('basic_table'); ?>
    <!-- this page js -->
    <script src="<?php echo e(asset('matrix/assets/extra-libs/multicheck/datatable-checkbox-init.js')); ?>"></script>
    <script src="<?php echo e(asset('matrix/assets/extra-libs/multicheck/jquery.multicheck.js')); ?>"></script>
    <script src="<?php echo e(asset('matrix/assets/extra-libs/DataTables/datatables.min.js')); ?>"></script>
<script>
      /****************************************
       *       Basic Table                   *
       ****************************************/
      $("#zero_config").DataTable();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/employee/permissions.blade.php ENDPATH**/ ?>