<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('consignee.consignee')); ?>" class="btn btn-success btn-sm">Back</a>
    </div>
    <form class="form-horizontal" action="<?php echo e(route('consignee.storeConsignee')); ?>" method="POST">
        <?php echo csrf_field(); ?>
      <div class="card-body">
        <h4 class="card-title">Add Consignee</h4>
        <?php if (isset($component)) { $__componentOriginal2342e1caa3b5224183b4572420a79d31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2342e1caa3b5224183b4572420a79d31 = $attributes; } ?>
<?php $component = App\View\Components\Message::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Message::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $attributes = $__attributesOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__attributesOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $component = $__componentOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__componentOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
        
        <div class="form-group row">
          <label for="consignee_name" class="col-sm-3 text-end control-label col-form-label">Consignee Name</label>
        <div class="col-sm-9"> 
            <input type="text" name="consignee_name" class="form-control" id="consignee_name" placeholder="Consignee Name" value="<?php echo e(old('consignee_country')); ?>" /> 
        </div> 
        </div>

        <div class="form-group row">
          <label for="consignee_site" class="col-sm-3 text-end control-label col-form-label">Consignee Site</label>
        <div class="col-sm-9"> 
            <input type="text" name="consignee_site" class="form-control" id="consignee_site" placeholder="Consignee site" value="<?php echo e(old('consignee_site')); ?>" /> 
        </div> 
        </div>

        <div class="form-group row">
          <label for="consignee_address" class="col-sm-3 text-end control-label col-form-label">Consignee Address</label>
        <div class="col-sm-9"> 
            <input type="text" name="consignee_address" class="form-control" id="consignee_address" placeholder="Consignee Address" value="<?php echo e(old('consignee_country')); ?>" />
        </div>
        </div>

        <div class="form-group row">
          <label for="consignee_country" class="col-sm-3 text-end control-label col-form-label">Consignee Country</label>
        <div class="col-sm-9"> 
            <input type="text" name="consignee_country" class="form-control" id="consignee_country" placeholder="Consignee Country" value="<?php echo e(old('consignee_country')); ?>" />
        </div>
        </div>
  

        <div class="border-top"> <div class="card-body"> 
            <input type="submit" value="Save" class="btn btn-primary">
        </div> </div>

    </form>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/consignee/addConsignee.blade.php ENDPATH**/ ?>