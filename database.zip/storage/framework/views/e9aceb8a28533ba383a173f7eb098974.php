<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">CM Value</h4>
                    <div class="table-responsive">
                        <form action="<?php echo e(route('cmValue.update', $cmValue->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>percentage</th>
                                        <th></th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <input type="number" name="cm_value" step="0.01" min="0" class="form-control" value="<?php echo e($cmValue->cm_value); ?>" required>
                                        </td>
                                        <td>%</td>
                                        <td>
                                            <button type="submit" class="btn btn-success">Update</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/cmValue/index.blade.php ENDPATH**/ ?>