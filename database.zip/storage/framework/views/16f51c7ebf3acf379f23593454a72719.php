<?php $__env->startSection('yajra_datatable_css'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" />
    <link href='https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route('audit.addAudit')); ?>" class="btn btn-success">Add New</a>
                    <?php if (isset($component)) { $__componentOriginal2342e1caa3b5224183b4572420a79d31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2342e1caa3b5224183b4572420a79d31 = $attributes; } ?>
<?php $component = App\View\Components\Message::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Message::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $attributes = $__attributesOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__attributesOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $component = $__componentOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__componentOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
                </div>
                <div class="card-body ">

                    <div class="table-responsive">
                        <?php echo e($dataTable->table()); ?>

                    </div>
                    
                </div>
            </div>
            

<?php $__env->stopSection(); ?>

<?php $__env->startSection('yajra_datatable_js'); ?>
    <!-- Yajra Datatables Scripts -->
    <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <!-- Yajra Datatables Buttons Scripts -->
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="/vendor/datatables/buttons.server-side.js"></script>
    <!-- Yajra Datatables Laravel Scripts -->
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/audit/indexAudit.blade.php ENDPATH**/ ?>