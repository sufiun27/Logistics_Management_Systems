<?php $__env->startSection('content'); ?>
<div class="card">
    
    <div class="card-body">
        
        <div class="card-header">
            <div class="card-title">Dashboard</div>
        </div>
       <div class="card-body">
        
       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>