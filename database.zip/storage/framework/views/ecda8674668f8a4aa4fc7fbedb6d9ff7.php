<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-header">
        <a href="<?php echo e(route('exportFormApparel.exportFormApparel')); ?>" class="btn btn-secondary btn-sm">Back</a>

    </div>
    <div class="card-title"><h4>Ex-Factory Information</h4></div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal2342e1caa3b5224183b4572420a79d31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2342e1caa3b5224183b4572420a79d31 = $attributes; } ?>
<?php $component = App\View\Components\Message::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Message::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $attributes = $__attributesOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__attributesOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $component = $__componentOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__componentOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
        <div class="row">
        <form action="<?php echo e(route('exportFormApparel.exportFormApparelExFactoryUpdate',$efa->id)); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <div class="col-6">
                <div class="form-group row">
                    <label for="exp_no" class="col-sm-3 text-end control-label col-form-label">Exp No: </label>
                    <div class="col-sm-9">
                        <input name="exp_no" id="exp_no" type="text" class="form-control" value="<?php echo e($efa->exp_no); ?>" placeholder="Exp No"/>
                    </div>
                   </div>

                   <div class="form-group row">
                    <label for="exp_date" class="col-sm-3 text-end control-label col-form-label">Exp Date: </label>
                    <div class="col-sm-9">
                        <input name="exp_date" id="exp_date" type="date" class="form-control" value="<?php echo e($efa->exp_date); ?>" placeholder="Exp Date"/>
                    </div>
                   </div>

                   <div class="form-group row">
                    <label for="exp_permit_no" class="col-sm-3 text-end control-label col-form-label">Exp Permit No: </label>
                    <div class="col-sm-9">
                        <input name="exp_permit_no" id="exp_permit_no" type="text" class="form-control" value="<?php echo e($efa->exp_permit_no); ?>" placeholder="Exp Permit No"/>
                    </div>
                   </div>

                   <div class="form-group row">
                    <label for="bl_no" class="col-sm-3 text-end control-label col-form-label">B/L No: </label>
                    <div class="col-sm-9">
                        <input name="bl_no" id="bl_no" type="text" class="form-control" value="<?php echo e($efa->bl_no); ?>" placeholder="B/L No"/>
                    </div>
                   </div>

                   <div class="form-group row">
                    <label for="bl_date" class="col-sm-3 text-end control-label col-form-label">B/L Date: </label>
                    <div class="col-sm-9">
                        <input name="bl_date" id="bl_date" type="date" class="form-control" value="<?php echo e($efa->bl_date); ?>" placeholder="B/L Date"/>
                    </div>
                   </div>

                   <div class="form-group row">
                    <label for="ex_factory_date" class="col-sm-3 text-end control-label col-form-label">EX-Factory Date: </label>
                    <div class="col-sm-9">
                        <input name="ex_factory_date" id="ex_factory_date" type="date" class="form-control" value="<?php echo e($efa->ex_factory_date); ?>" placeholder="EX-Factory Date"/>
                    </div>
                   </div>


            </div>


            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/exportFormApparel/exportFormApparelExFactory.blade.php ENDPATH**/ ?>