<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('exportFormApparel.exportFormApparel')); ?>" class="btn btn-dark btn-sm">Back</a>
        <a href="<?php echo e(route('exportFormApparel.exportFormApparelExFactory', $efa->id)); ?>" class="btn btn-success btn-sm">Ex-Factory</a>
        <a href="<?php echo e(route('exportFormApparel.exportFormApparelEdit', $efa->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
        <a href="<?php echo e(route('exportFormApparel.exportFormApparelDelete', $efa->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
        <a href="<?php echo e(route('exportFormApparel.exportFormApparelDetailsPdf', $efa->id)); ?>" target="_blank" class="btn btn-info btn-sm">PDF</a>
    </div>
    <div class="card-title"><h2>Export Form</h2></div>
    <hr>

    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <dl class="row">
                    <dt class="col-sm-4">Item Name:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->item_name ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">HS Code:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->hs_code ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">HS Code Second:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->hs_code_second ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Invoice No:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->invoice_no); ?></dd>

                    <dt class="col-sm-4">Invoice Date:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->invoice_date ? \Illuminate\Support\Carbon::parse($efa->invoice_date)->format('Y-m-d') : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Contract No:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->contract_no ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Contract Date:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->contract_date ? \Illuminate\Support\Carbon::parse($efa->contract_date)->format('Y-m-d') : 'N/A'); ?></dd>
                </dl>
            </div>

            <div class="col-md-6">
                <dl class="row">
                    <dt class="col-sm-4">Consignee Name:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->consignee_name ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Consignee Site:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->consignee_site ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Consignee Address:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->consignee_address ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">DST Country Code:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->dst_country_code ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">DST Country Name:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->dst_country_name ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">DST Country Port:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->dst_country_port ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Section:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->section ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">TT No:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->tt_no ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">TT Date:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->tt_date ? \Illuminate\Support\Carbon::parse($efa->tt_date)->format('Y-m-d') : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Invoice Site:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->invoice_site ?? 'N/A'); ?></dd>
                </dl>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <h4>Quantity & Value</h4>
                <hr>
                <dl class="row">
                    <dt class="col-sm-4">Unit:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->unit ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Quantity:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->quantity ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Currency:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->currency ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Amount:</dt>
                    <dd class="col-sm-8"><?php echo e(isset($efa->amount) ? number_format($efa->amount, 4) : 'N/A'); ?></dd>

                    <dt class="col-sm-4">CM Percentage:</dt>
                    <dd class="col-sm-8"><?php echo e(isset($efa->cm_percentage) ? number_format($efa->cm_percentage, 4) : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Incoterm:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->incoterm ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">CM Amount:</dt>
                    <dd class="col-sm-8"><?php echo e(isset($efa->cm_amount) ? number_format($efa->cm_amount, 4) : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Freight Value:</dt>
                    <dd class="col-sm-8"><?php echo e(isset($efa->freight_value) ? number_format($efa->freight_value, 4) : 'N/A'); ?></dd>
                </dl>
            </div>

            <div class="col-md-6">
                <h4>Transport & Notify Information</h4>
                <hr>
                <dl class="row">
                    <dt class="col-sm-4">Transport Name:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->transport_name ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Transport Address:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->transport_address ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Transport Port:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->transport_port ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Notify Name:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->notify_name ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Notify Address:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->notify_address ?? 'N/A'); ?></dd>
                </dl>

                <h4>Ex-Factory Information</h4>
                <hr>
                <dl class="row">
                    <dt class="col-sm-4">Exp No:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->exp_no ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Exp Date:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->exp_date ? \Illuminate\Support\Carbon::parse($efa->exp_date)->format('Y-m-d') : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Exp Permit No:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->exp_permit_no ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">BL No:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->bl_no ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">BL Date:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->bl_date ? \Illuminate\Support\Carbon::parse($efa->bl_date)->format('Y-m-d') : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Ex Factory Date:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->ex_factory_date ? \Illuminate\Support\Carbon::parse($efa->ex_factory_date)->format('Y-m-d') : 'N/A'); ?></dd>
                </dl>

                <h4>Audit Information</h4>
                <hr>
                <dl class="row">
                    <dt class="col-sm-4">Created By:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->create_by ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Created At:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->created_at ? \Illuminate\Support\Carbon::parse($efa->created_at)->format('Y-m-d H:i:s') : 'N/A'); ?></dd>

                    <dt class="col-sm-4">Updated By:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->update_by ?? 'N/A'); ?></dd>

                    <dt class="col-sm-4">Updated At:</dt>
                    <dd class="col-sm-8"><?php echo e($efa->updated_at ? \Illuminate\Support\Carbon::parse($efa->updated_at)->format('Y-m-d H:i:s') : 'N/A'); ?></dd>
                </dl>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/exportFormApparel/exportFormApparelDetails.blade.php ENDPATH**/ ?>