<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Notify Details</h1>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($notify->name); ?></h5>
            <p class="card-text"><strong>Address:</strong> <?php echo e($notify->address ?? 'N/A'); ?></p>
            <p class="card-text"><strong>Created At:</strong> <?php echo e($notify->created_at); ?></p>
            <p class="card-text"><strong>Updated At:</strong> <?php echo e($notify->updated_at); ?></p>
            <a href="<?php echo e(route('notify.index')); ?>" class="btn btn-primary">Back to List</a>
            <a href="<?php echo e(route('notify.edit', $notify)); ?>" class="btn btn-warning">Edit</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/notify/show.blade.php ENDPATH**/ ?>