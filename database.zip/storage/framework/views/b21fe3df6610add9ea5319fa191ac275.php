<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('DestCountry.DestCountry')); ?>" class="btn btn-success btn-sm">Back</a>
    </div>
    <div class="card-body">
        <?php if (isset($component)) { $__componentOriginal2342e1caa3b5224183b4572420a79d31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2342e1caa3b5224183b4572420a79d31 = $attributes; } ?>
<?php $component = App\View\Components\Message::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Message::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $attributes = $__attributesOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__attributesOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $component = $__componentOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__componentOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
        <p>Add Destination Country</p>
        <form action="<?php echo e(route('DestCountry.storeDestCountry')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="country_code" placeholder="Country Code" value="<?php echo e(old('country_code')); ?>" class="form-control"><br>
            <input type="text" name="country_name" placeholder="Country Name" value="<?php echo e(old('country_name')); ?>" class="form-control"><br>
            <input type="text" name="port" placeholder="Port" class="form-control" value="<?php echo e(old('port')); ?>"><br>
            <input type="submit" value="Save" class="btn btn-primary btn-sm">
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/DestCountry/addDestCountry.blade.php ENDPATH**/ ?>