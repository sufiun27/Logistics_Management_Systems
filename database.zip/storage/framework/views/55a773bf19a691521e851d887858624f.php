<?php $__env->startSection('content'); ?>
    <!-- resources/views/exporter/create.blade.php -->
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('export.storeExporter')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="ExpoterNo" class="form-label">Exporter Number:</label>
                <input type="text" name="ExpoterNo" class="form-control" value="<?php echo e(old('ExpoterNo')); ?>" required>
            </div>
    
            <div class="mb-3">
                <label for="ExpoterName" class="form-label">Exporter Name:</label>
                <input type="text" name="ExpoterName" class="form-control" value="<?php echo e(old('ExpoterName')); ?>" required>
            </div>
    
            <div class="mb-3">
                <label for="ExpoterAddress" class="form-label">Exporter Address:</label>
                <input type="text" name="ExpoterAddress" class="form-control" value="<?php echo e(old('ExpoterAddress')); ?>" required>
            </div>
    
            <div class="mb-3">
                <label for="RegDetails" class="form-label">Registration Details:</label>
                <input type="text" name="RegDetails" class="form-control" value="<?php echo e(old('RegDetails')); ?>" required>
            </div>
    
            <div class="mb-3">
                <label for="EPBReg" class="form-label">EPB Registration:</label>
                <input type="text" name="EPBReg" class="form-control" value="<?php echo e(old('EPBReg')); ?>" required>
            </div>
    
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\github\Hoplun\Logistics_Management_Systems\resources\views/export/addExporter.blade.php ENDPATH**/ ?>