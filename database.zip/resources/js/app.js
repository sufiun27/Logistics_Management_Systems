import './bootstrap';

import 'laravel-datatables-vite';//for yajan/laravel-datatables-vite