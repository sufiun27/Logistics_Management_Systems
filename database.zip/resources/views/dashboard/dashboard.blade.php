@extends('template.index')
@section('content')
<div class="card">
    
    <div class="card-body">
        {{-- {{$exporters}} --}}
        <div class="card-header">
            <div class="card-title">Dashboard</div>
        </div>
       <div class="card-body">
        {{-- <h5>Developed By Abu Sufiun</h5> --}}
       </div>
    </div>
</div>
@endsection